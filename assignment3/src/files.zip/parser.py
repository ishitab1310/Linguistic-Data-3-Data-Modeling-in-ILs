"""
parser.py
---------
CoNLL-U / CoNLL-2006 treebank loader.

Handles both standard CoNLL-U (10 columns) and older CoNLL-2006 style
(8 columns) files, as well as mixed/malformed files found in LTRC treebanks.
Returns a flat pandas DataFrame with one row per token.
"""

import os
import re
import pandas as pd


# ---------------------------------------------------------------------------
# Column schemas
# ---------------------------------------------------------------------------

CONLLU_COLS = ["id", "form", "lemma", "upos", "xpos", "feats", "head", "deprel", "deps", "misc"]
CONLL06_COLS = ["id", "form", "lemma", "cpos", "xpos", "feats", "head", "deprel"]


def _parse_id(val: str):
    """Return integer token id; skip range/empty nodes (e.g. '1-2', '0.1')."""
    if re.fullmatch(r"\d+", val):
        return int(val)
    return None


def _parse_head(val: str):
    """Return integer head; treat '_' or non-numeric as None."""
    if re.fullmatch(r"\d+", val):
        return int(val)
    return None


def parse_file(path: str, lang: str = "") -> pd.DataFrame:
    """
    Parse a single CoNLL-U or CoNLL-2006 file.

    Parameters
    ----------
    path : str
        Path to the .conllu / .conll file.
    lang : str
        Language label added as a column (optional).

    Returns
    -------
    pd.DataFrame
    """
    rows = []
    sent_id = 0

    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.rstrip("\n")

            # blank line → sentence boundary
            if line == "":
                sent_id += 1
                continue

            # comment / metadata
            if line.startswith("#"):
                continue

            parts = line.split("\t")

            # skip malformed lines with fewer than 8 fields
            if len(parts) < 8:
                continue

            tok_id = _parse_id(parts[0])
            if tok_id is None:          # range / empty node — skip
                continue

            head = _parse_head(parts[6])

            feats_raw = parts[5] if parts[5] != "_" else None

            row = {
                "sent_id":  sent_id,
                "id":       tok_id,
                "form":     parts[1],
                "lemma":    parts[2],
                "upos":     parts[3] if parts[3] != "_" else None,
                "xpos":     parts[4] if parts[4] != "_" else None,
                "feats":    feats_raw,
                "head":     head,
                "deprel":   parts[7] if parts[7] != "_" else None,
                "lang":     lang,
            }
            rows.append(row)

    df = pd.DataFrame(rows)

    # coerce numeric columns
    for col in ("id", "head"):
        df[col] = pd.to_numeric(df[col], errors="coerce")

    return df


def load_treebank(root: str, lang: str, extensions=(".conllu", ".conll", ".conll06")) -> pd.DataFrame:
    """
    Recursively load all treebank files under *root* whose extension is in
    *extensions*.

    Parameters
    ----------
    root : str
        Root directory of the treebank.
    lang : str
        Language label (e.g. 'Hindi', 'Telugu').
    extensions : tuple
        File extensions to consider.

    Returns
    -------
    pd.DataFrame
        Combined DataFrame for the whole treebank.
    """
    frames = []

    for dirpath, _, filenames in os.walk(root):
        for fname in filenames:
            if any(fname.endswith(ext) for ext in extensions):
                fpath = os.path.join(dirpath, fname)
                try:
                    df = parse_file(fpath, lang=lang)
                    if not df.empty:
                        frames.append(df)
                except Exception as exc:
                    print(f"[parser] Warning: could not parse {fpath}: {exc}")

    if not frames:
        raise FileNotFoundError(
            f"No treebank files found under '{root}' with extensions {extensions}."
        )

    combined = pd.concat(frames, ignore_index=True)
    print(f"[parser] Loaded {lang}: {len(combined):,} tokens from {len(frames)} file(s).")
    return combined
