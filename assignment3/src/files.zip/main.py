"""
main.py
-------
Orchestrates the full Part 1 corpus analysis pipeline.

Usage
-----
    python main.py --telugu <path_to_telugu_treebank> --hindi <path_to_hindi_treebank>

Both paths should point to the ROOT directory of each treebank (the script
walks subdirectories recursively looking for .conllu / .conll files).

Example
-------
    python main.py \
        --telugu data/telugu_treebank \
        --hindi  data/hindi_treebank
"""

import argparse
import os
import sys

# make sure src/ is on the path when called from project root
sys.path.insert(0, os.path.dirname(__file__))

from parser              import load_treebank
from dependency_analysis import run_all as run_dependency
from morphology_analysis import run_all as run_morphology


def parse_args():
    p = argparse.ArgumentParser(description="Hindi-Telugu treebank analysis")
    p.add_argument("--telugu", required=True, help="Root directory of Telugu treebank")
    p.add_argument("--hindi",  required=True, help="Root directory of Hindi treebank")
    return p.parse_args()


def main():
    args = parse_args()

    os.makedirs("results", exist_ok=True)

    # ── Load treebanks ──────────────────────────────────────────────────────
    print("\n[main] Loading treebanks …")
    telugu = load_treebank(args.telugu, lang="Telugu")
    hindi  = load_treebank(args.hindi,  lang="Hindi")

    # ── Part 1 Q1–Q4: Dependency analysis ──────────────────────────────────
    print("\n[main] Running dependency distance analysis (Q1–Q4) …")
    dep_results = run_dependency(telugu, hindi)

    # ── Part 1 Q5–Q6: Morphology analysis ──────────────────────────────────
    print("\n[main] Running morphological feature analysis (Q5–Q6) …")
    morph_results = run_morphology(telugu, hindi)

    # ── Summary ─────────────────────────────────────────────────────────────
    print("\n" + "="*50)
    print("Analysis complete.  All outputs saved to results/")
    print("="*50)

    t_stats = dep_results["telugu_stats"]
    h_stats = dep_results["hindi_stats"]
    sig     = dep_results["sig"]

    print(f"\n  Telugu mean dep distance : {t_stats['mean']}")
    print(f"  Hindi  mean dep distance : {h_stats['mean']}")
    print(f"  Mann-Whitney U p-value   : {sig['p_value']:.4e}")
    print(f"  Significant (α=0.05)     : {sig['significant']}")


if __name__ == "__main__":
    main()
