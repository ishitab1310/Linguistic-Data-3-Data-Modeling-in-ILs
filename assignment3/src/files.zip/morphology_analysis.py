"""
morphology_analysis.py
----------------------
Q5 – Extract and compare morphological features (Number, Gender, Case, …)
Q6 – Typological discussion data (feature-level comparison table + heatmap)

CoNLL-U morph features use '=' as key-value separator, '|' between features.
Example:  Number=Sing|Gender=Masc|Case=Nom
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

RESULTS = "results"
os.makedirs(RESULTS, exist_ok=True)


# ---------------------------------------------------------------------------
# Feature extraction
# ---------------------------------------------------------------------------

def extract_morph_features(df: pd.DataFrame) -> pd.Series:
    """
    Parse the 'feats' column (CoNLL-U format) and count feature category
    occurrences (e.g. Number, Gender, Case).

    Returns a Series sorted by descending frequency.
    """
    counts: dict[str, int] = {}

    for cell in df["feats"].dropna():
        for pair in cell.split("|"):
            # CoNLL-U uses '=', not '-'
            if "=" in pair:
                key = pair.split("=", 1)[0].strip()
                counts[key] = counts.get(key, 0) + 1

    return pd.Series(counts).sort_values(ascending=False)


def extract_feature_values(df: pd.DataFrame) -> dict[str, pd.Series]:
    """
    Return a dict mapping feature category → value frequency Series.
    E.g. {'Number': Series({'Sing': 5000, 'Plur': 1200, ...}), ...}
    """
    feat_vals: dict[str, dict[str, int]] = {}

    for cell in df["feats"].dropna():
        for pair in cell.split("|"):
            if "=" in pair:
                key, val = pair.split("=", 1)
                key = key.strip()
                val = val.strip()
                if key not in feat_vals:
                    feat_vals[key] = {}
                feat_vals[key][val] = feat_vals[key].get(val, 0) + 1

    return {k: pd.Series(v).sort_values(ascending=False) for k, v in feat_vals.items()}


# ---------------------------------------------------------------------------
# Q5 – Bar charts + comparison table
# ---------------------------------------------------------------------------

def plot_feature_bar(feat_series: pd.Series, lang: str, top_n: int = 15):
    """Bar chart of top-N morphological feature categories for one language."""
    top = feat_series.head(top_n)

    fig, ax = plt.subplots(figsize=(10, 6))
    color = "#2196F3" if lang == "Telugu" else "#F44336"
    top.plot(kind="bar", ax=ax, color=color, alpha=0.85)

    ax.set_xlabel("Feature Category", fontsize=12)
    ax.set_ylabel("Token Count", fontsize=12)
    ax.set_title(f"Top Morphological Features — {lang}", fontsize=14)
    ax.tick_params(axis="x", rotation=40)

    plt.tight_layout()
    path = os.path.join(RESULTS, f"{lang.lower()}_morph_features.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"[plot] Saved → {path}")


def plot_feature_comparison(telugu_feats: pd.Series, hindi_feats: pd.Series, top_n: int = 15):
    """Grouped bar chart: feature categories present in either language."""
    all_keys = list(
        dict.fromkeys(
            list(telugu_feats.head(top_n).index) + list(hindi_feats.head(top_n).index)
        )
    )

    t_vals = [telugu_feats.get(k, 0) for k in all_keys]
    h_vals = [hindi_feats.get(k, 0) for k in all_keys]

    x = np.arange(len(all_keys))
    width = 0.38

    fig, ax = plt.subplots(figsize=(14, 7))
    ax.bar(x - width/2, t_vals, width, label="Telugu", color="#2196F3", alpha=0.85)
    ax.bar(x + width/2, h_vals, width, label="Hindi",  color="#F44336", alpha=0.85)

    ax.set_xticks(x)
    ax.set_xticklabels(all_keys, rotation=40, ha="right", fontsize=10)
    ax.set_ylabel("Token Count", fontsize=12)
    ax.set_title("Morphological Feature Comparison: Hindi vs Telugu", fontsize=14)
    ax.legend(fontsize=11)

    plt.tight_layout()
    path = os.path.join(RESULTS, "morph_feature_comparison.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"[plot] Saved → {path}")


def save_feature_tables(telugu_feats: pd.Series, hindi_feats: pd.Series):
    """Save per-language and merged comparison CSVs."""
    # individual
    for feats, lang in [(telugu_feats, "telugu"), (hindi_feats, "hindi")]:
        df = feats.reset_index()
        df.columns = ["feature", "count"]
        path = os.path.join(RESULTS, f"{lang}_morph_features.csv")
        df.to_csv(path, index=False)
        print(f"[csv] Saved → {path}")

    # merged comparison
    merged = pd.DataFrame({
        "Telugu": telugu_feats,
        "Hindi":  hindi_feats,
    }).fillna(0).astype(int)
    merged.index.name = "Feature"
    merged["Total"] = merged["Telugu"] + merged["Hindi"]
    merged = merged.sort_values("Total", ascending=False)
    path = os.path.join(RESULTS, "morph_feature_comparison.csv")
    merged.reset_index().to_csv(path, index=False)
    print(f"[csv] Saved → {path}")
    return merged


def plot_heatmap(merged_df: pd.DataFrame, top_n: int = 20):
    """Heatmap of normalised feature frequencies for top-N features."""
    top = merged_df.drop(columns="Total").head(top_n).copy()

    # normalise each language column by its own total (relative frequency)
    top_norm = top.div(top.sum(axis=0), axis=1) * 100

    fig, ax = plt.subplots(figsize=(8, max(6, top_n // 2)))
    sns.heatmap(
        top_norm, annot=True, fmt=".1f", cmap="YlOrRd",
        linewidths=0.5, ax=ax, cbar_kws={"label": "% of total feature tokens"}
    )
    ax.set_title("Normalised Morphological Feature Frequencies (%)", fontsize=13)
    ax.set_xlabel("Language", fontsize=11)
    ax.set_ylabel("Feature Category", fontsize=11)

    plt.tight_layout()
    path = os.path.join(RESULTS, "morph_feature_heatmap.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"[plot] Saved → {path}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run_all(telugu_raw: pd.DataFrame, hindi_raw: pd.DataFrame):
    """
    Called from main.py.

    Parameters
    ----------
    telugu_raw, hindi_raw : pd.DataFrame
        Raw token DataFrames from parser.load_treebank().
    """
    print("\n" + "="*40)
    print("Morphological Feature Analysis")
    print("="*40)

    telugu_feats = extract_morph_features(telugu_raw)
    hindi_feats  = extract_morph_features(hindi_raw)

    print("\nTop Telugu Features:")
    print(telugu_feats.head(15).to_string())
    print("\nTop Hindi Features:")
    print(hindi_feats.head(15).to_string())

    # plots
    plot_feature_bar(telugu_feats, "Telugu")
    plot_feature_bar(hindi_feats,  "Hindi")
    plot_feature_comparison(telugu_feats, hindi_feats)

    # tables
    merged = save_feature_tables(telugu_feats, hindi_feats)

    # heatmap
    plot_heatmap(merged)

    # also extract feature value distributions for the report
    t_vals = extract_feature_values(telugu_raw)
    h_vals = extract_feature_values(hindi_raw)

    return {
        "telugu_feats": telugu_feats,
        "hindi_feats":  hindi_feats,
        "telugu_vals":  t_vals,
        "hindi_vals":   h_vals,
        "merged":       merged,
    }
